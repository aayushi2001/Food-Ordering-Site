import fastFood from "../src/images/1.jpg";
import burger from "../src/images/2.jpg";
import pi from "../src/images/c9.jpg";
import di from "../src/images/4.jpg";
import ma from "../src/images/5.jpg";
import so from "../src/images/bg1.jpeg";

const Sdata = [
  {
    imgsrc: fastFood,
    title: "Pizza",
    tag:"You will enjoy our fast food",

  },
  {
    imgsrc: burger,
    title: "Burger",
    tag:"Eat with Fun",
  },
  {
    imgsrc: pi,
    title: "Special Cakes",
    tag:"Happiness for your loved ones",
  },
  {
    imgsrc: di,
    title: "Fries",
    tag:"Eat something spicy",
  },
  {
    imgsrc: so,
    title: "Special Dish",
    tag:"Lovely Dishes",
  },
  {
    imgsrc: ma,
    title: "Shakes",
    tag:"Drink something nice"
  },
];

export default Sdata;
